/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bibliotecado;

/**
 *
 * @author deyve
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Bibliotecado {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Application());
    }
}

class Autor {

    private String nombre;
    private String apellido;

    public Autor(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public String mostrarInfo() {
        return "Autor: " + nombre + " " + apellido;
    }
}

class Categoria {

    private String nombre;

    public Categoria(String nombre) {
        this.nombre = nombre;
    }

    public String mostrarInfo() {
        return "Categoría: " + nombre;
    }
}

class Libro {

    private String titulo;
    private String isbn;
    private Autor autor;
    private Categoria categoria;

    public Libro(String titulo, String isbn, Autor autor, Categoria categoria) {
        this.titulo = titulo;
        this.isbn = isbn;
        this.autor = autor;
        this.categoria = categoria;
    }

    public String mostrarInfo() {
        return "Libro: " + titulo + " (ISBN: " + isbn + "), " + autor.mostrarInfo() + ", " + categoria.mostrarInfo();
    }

    public String getTitulo() {
        return titulo;
    }
}

class Usuario {

    private String nombre;
    private String apellido;
    private int idUsuario;

    public Usuario(String nombre, String apellido, int idUsuario) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.idUsuario = idUsuario;
    }

    public String mostrarInfo() {
        return "Usuario: " + nombre + " " + apellido + " (ID: " + idUsuario + ")";
    }

    public int getIdUsuario() {
        return idUsuario;
    }
}

class Prestamo {

    private Libro libro;
    private Usuario usuario;
    private String fechaPrestamo;
    private String fechaDevolucion;

    public Prestamo(Libro libro, Usuario usuario, String fechaPrestamo) {
        this.libro = libro;
        this.usuario = usuario;
        this.fechaPrestamo = fechaPrestamo;
    }

    public void setFechaDevolucion(String fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    public String mostrarInfo() {
        String devolucion = (fechaDevolucion != null) ? fechaDevolucion : "No devuelto";
        return "Préstamo: " + libro.getTitulo() + ", Usuario: " + usuario.mostrarInfo() + ", Desde: " + fechaPrestamo + ", Hasta: " + devolucion;
    }

    public Libro getLibro() {
        return libro;
    }

    public Usuario getUsuario() {
        return usuario;
    }
}

class Biblioteca {

    private ArrayList<Libro> libros;
    private ArrayList<Usuario> usuarios;
    private ArrayList<Prestamo> prestamos;

    public Biblioteca() {
        libros = new ArrayList<>();
        usuarios = new ArrayList<>();
        prestamos = new ArrayList<>();
    }

    public void registrarLibro(Libro libro) {
        libros.add(libro);
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public void realizarPrestamo(Libro libro, Usuario usuario, String fechaPrestamo) {
        Prestamo prestamo = new Prestamo(libro, usuario, fechaPrestamo);
        prestamos.add(prestamo);
    }

    public void devolverLibro(Prestamo prestamo, String fechaDevolucion) {
        prestamo.setFechaDevolucion(fechaDevolucion);
    }

    public ArrayList<String> mostrarLibros() {
        ArrayList<String> librosInfo = new ArrayList<>();
        for (Libro libro : libros) {
            librosInfo.add(libro.mostrarInfo());
        }
        return librosInfo;
    }

    public ArrayList<String> mostrarUsuarios() {
        ArrayList<String> usuariosInfo = new ArrayList<>();
        for (Usuario usuario : usuarios) {
            usuariosInfo.add(usuario.mostrarInfo());
        }
        return usuariosInfo;
    }

    public ArrayList<String> mostrarPrestamos() {
        ArrayList<String> prestamosInfo = new ArrayList<>();
        for (Prestamo prestamo : prestamos) {
            prestamosInfo.add(prestamo.mostrarInfo());
        }
        return prestamosInfo;
    }

    public Libro buscarLibroPorTitulo(String titulo) {
        for (Libro libro : libros) {
            if (libro.getTitulo().equals(titulo)) {
                return libro;
            }
        }
        return null;
    }

    public Usuario buscarUsuarioPorId(int idUsuario) {
        for (Usuario usuario : usuarios) {
            if (usuario.getIdUsuario() == idUsuario) {
                return usuario;
            }
        }
        return null;
    }

    public Prestamo buscarPrestamo(String titulo, int idUsuario) {
        for (Prestamo prestamo : prestamos) {
            if (prestamo.getLibro().getTitulo().equals(titulo) && prestamo.getUsuario().getIdUsuario() == idUsuario) {
                return prestamo;
            }
        }
        return null;
    }
}

class Application extends JFrame {

    private JTextField tituloField, isbnField, autorField, categoriaField;
    private JTextField nombreUsuarioField, apellidoUsuarioField, idUsuarioField;
    private JTextField tituloPrestamoField, idUsuarioPrestamoField;
    private JTextArea infoArea;
    private Biblioteca biblioteca;

    public Application() {
        setTitle("Biblioteca");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        biblioteca = new Biblioteca();

        createWidgets();
        setVisible(true);
    }

    private void createWidgets() {
        JPanel panelLibros = new JPanel(new GridLayout(5, 2, 5, 5));
        panelLibros.setBorder(BorderFactory.createTitledBorder("Gestión de Libros"));

        panelLibros.add(new JLabel("Título:"));
        tituloField = new JTextField();
        panelLibros.add(tituloField);

        panelLibros.add(new JLabel("ISBN:"));
        isbnField = new JTextField();
        panelLibros.add(isbnField);

        panelLibros.add(new JLabel("Autor:"));
        autorField = new JTextField();
        panelLibros.add(autorField);

        panelLibros.add(new JLabel("Categoría:"));
        categoriaField = new JTextField();
        panelLibros.add(categoriaField);

        JButton registrarLibroButton = new JButton("Registrar Libro");
        registrarLibroButton.addActionListener(e -> registrarLibro());
        panelLibros.add(registrarLibroButton);

        add(panelLibros, BorderLayout.NORTH);

        JPanel panelUsuarios = new JPanel(new GridLayout(4, 2, 5, 5));
        panelUsuarios.setBorder(BorderFactory.createTitledBorder("Gestión de Usuarios"));

        panelUsuarios.add(new JLabel("Nombre:"));
        nombreUsuarioField = new JTextField();
        panelUsuarios.add(nombreUsuarioField);

        panelUsuarios.add(new JLabel("Apellido:"));
        apellidoUsuarioField = new JTextField();
        panelUsuarios.add(apellidoUsuarioField);

        panelUsuarios.add(new JLabel("ID Usuario:"));
        idUsuarioField = new JTextField();
        panelUsuarios.add(idUsuarioField);

        JButton registrarUsuarioButton = new JButton("Registrar Usuario");
        registrarUsuarioButton.addActionListener(e -> registrarUsuario());
        panelUsuarios.add(registrarUsuarioButton);

        add(panelUsuarios, BorderLayout.CENTER);

        JPanel panelPrestamos = new JPanel(new GridLayout(4, 2, 5, 5));
        panelPrestamos.setBorder(BorderFactory.createTitledBorder("Gestión de Préstamos"));

        panelPrestamos.add(new JLabel("Título del Libro:"));
        tituloPrestamoField = new JTextField();
        panelPrestamos.add(tituloPrestamoField);

        panelPrestamos.add(new JLabel("ID Usuario:"));
        idUsuarioPrestamoField = new JTextField();
        panelPrestamos.add(idUsuarioPrestamoField);

        JButton realizarPrestamoButton = new JButton("Realizar Préstamo");
        realizarPrestamoButton.addActionListener(e -> realizarPrestamo());
        panelPrestamos.add(realizarPrestamoButton);

        JButton devolverLibroButton = new JButton("Devolver Libro");
        devolverLibroButton.addActionListener(e -> devolverLibro());
        panelPrestamos.add(devolverLibroButton);

        add(panelPrestamos, BorderLayout.SOUTH);

        infoArea = new JTextArea();
        infoArea.setEditable(false);
        add(new JScrollPane(infoArea), BorderLayout.EAST);

        JPanel panelBotones = new JPanel(new FlowLayout());

        JButton mostrarLibrosButton = new JButton("Mostrar Libros");
        mostrarLibrosButton.addActionListener(e -> mostrarLibros());
        panelBotones.add(mostrarLibrosButton);

        JButton mostrarUsuariosButton = new JButton("Mostrar Usuarios");
        mostrarUsuariosButton.addActionListener(e -> mostrarUsuarios());
        panelBotones.add(mostrarUsuariosButton);

        JButton mostrarPrestamosButton = new JButton("Mostrar Préstamos");
        mostrarPrestamosButton.addActionListener(e -> mostrarPrestamos());
        panelBotones.add(mostrarPrestamosButton);

        add(panelBotones, BorderLayout.WEST);
    }

    private void registrarLibro() {
        String titulo = tituloField.getText();
        String isbn = isbnField.getText();
        String nombreAutor = autorField.getText();
        String nombreCategoria = categoriaField.getText();

        if (!titulo.isEmpty() && !isbn.isEmpty() && !nombreAutor.isEmpty() && !nombreCategoria.isEmpty()) {
            Autor autor = new Autor(nombreAutor, "");
            Categoria categoria = new Categoria(nombreCategoria);
            Libro libro = new Libro(titulo, isbn, autor, categoria);
            biblioteca.registrarLibro(libro);
            JOptionPane.showMessageDialog(this, "Libro registrado exitosamente");
            tituloField.setText("");
            isbnField.setText("");
            autorField.setText("");
            categoriaField.setText("");
            mostrarLibros();
        } else {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void registrarUsuario() {
        String nombre = nombreUsuarioField.getText();
        String apellido = apellidoUsuarioField.getText();
        String idUsuarioStr = idUsuarioField.getText();

        if (!nombre.isEmpty() && !apellido.isEmpty() && !idUsuarioStr.isEmpty()) {
            int idUsuario = Integer.parseInt(idUsuarioStr);
            Usuario usuario = new Usuario(nombre, apellido, idUsuario);
            biblioteca.registrarUsuario(usuario);
            JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente");
            nombreUsuarioField.setText("");
            apellidoUsuarioField.setText("");
            idUsuarioField.setText("");
            mostrarUsuarios();
        } else {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void realizarPrestamo() {
        String titulo = tituloPrestamoField.getText();
        String idUsuarioStr = idUsuarioPrestamoField.getText();

        Libro libro = biblioteca.buscarLibroPorTitulo(titulo);
        Usuario usuario = biblioteca.buscarUsuarioPorId(Integer.parseInt(idUsuarioStr));

        if (libro != null && usuario != null) {
            String fechaPrestamo = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            biblioteca.realizarPrestamo(libro, usuario, fechaPrestamo);
            JOptionPane.showMessageDialog(this, "Préstamo realizado exitosamente");
            tituloPrestamoField.setText("");
            idUsuarioPrestamoField.setText("");
            mostrarPrestamos();
        } else {
            JOptionPane.showMessageDialog(this, "Libro o Usuario no encontrados", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void devolverLibro() {
        String titulo = tituloPrestamoField.getText();
        String idUsuarioStr = idUsuarioPrestamoField.getText();

        Prestamo prestamo = biblioteca.buscarPrestamo(titulo, Integer.parseInt(idUsuarioStr));

        if (prestamo != null) {
            String fechaDevolucion = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            biblioteca.devolverLibro(prestamo, fechaDevolucion);
            JOptionPane.showMessageDialog(this, "Libro devuelto exitosamente");
            tituloPrestamoField.setText("");
            idUsuarioPrestamoField.setText("");
            mostrarPrestamos();
        } else {
            JOptionPane.showMessageDialog(this, "Préstamo no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarLibros() {
        infoArea.setText("");
        ArrayList<String> librosInfo = biblioteca.mostrarLibros();
        for (String info : librosInfo) {
            infoArea.append(info + "\n");
        }
    }

    private void mostrarUsuarios() {
        infoArea.setText("");
        ArrayList<String> usuariosInfo = biblioteca.mostrarUsuarios();
        for (String info : usuariosInfo) {
            infoArea.append(info + "\n");
        }
    }

    private void mostrarPrestamos() {
        infoArea.setText("");
        ArrayList<String> prestamosInfo = biblioteca.mostrarPrestamos();
        for (String info : prestamosInfo) {
            infoArea.append(info + "\n");
        }
    }

}
